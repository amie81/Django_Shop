from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import HttpResponse
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from django.views import View
from store.models.product import Product
from store.models.orders import Order


# Create your views here.

class Index(View):

    def post(self, request):

        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart', request.session['cart'])

        return redirect('homepage')

    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None

        categories = Category.get_all_categories()
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.get_all_products_by_id(categoryID)
        else:
            products = Product.get_all_products()

        data = {}
        data['products'] = products
        data['categories'] = categories
        print('You are:', request.session.get('email'))
        return render(request, 'index.html', data)


def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        contactno = postData.get('contactno')
        email = postData.get('email')
        password = postData.get('password')

        # validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'contactno': contactno,
            'email': email
        }
        error_message = None

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            contactno=contactno,
                            email=email,
                            password=password)

        if not first_name:
            error_message = "First Name Required !!"
        elif not last_name:
            error_message = "Last Name Required !!"
        elif not contactno:
            error_message = "Contact No Required !!"
        elif len(contactno) < 10:
            error_message = "Contact no must be of 10 digits !!"
        elif not password:
            error_message = "Password Required !!"
        elif len(password) < 6:
            error_message = "Password must be 6 character long !!"
        elif not email:
            error_message = "Enter Valid Email address !!"
        elif customer.isExists():
            error_message = 'E-Mail address already registered !!'
        # saving
        if not error_message:
            print(first_name, last_name, contactno, email, password)

            customer.register()

            return render(request, 'login.html')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)


class Login(View):
    return_url = None

    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)

        error_message = None
        if customer:
            flag = customer.password
            if flag:
                request.session['customer'] = customer.id
                request.session['email'] = customer.email

                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
            else:
                error_message = 'email or Password is invalid'
        else:
            error_message = 'email or Password is invalid'
        print(email, password)
        return render(request, 'login.html', {'error': error_message})


def logout(request):
    request.session.clear()
    return redirect('login')


def cart(request):
    if request.method == 'GET':
        ids = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(ids)
        print(products)
        return render(request, 'cart.html', {'products': products})


def checkout(request):
    if request.method == 'POST':
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address, phone, customer, cart, products)
    if customer:
        for product in products:
            print(cart.get(str(product.id)))
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          phone=phone,
                          quantity=cart.get(str(product.id)))
            order.save()
            request.session['cart'] = {}
        return redirect('cart')
    else:
        err = None
        err = 'Please Log in first to place an order'
        return render(request, 'login.html', {'error': err})


class orders(View):

    def get(self, request):
        customer = request.session.get('customer')
        ord = Order.get_orders_by_customer(customer)
        print(ord)
        # ord = ord.reverse()
        return render(request, 'orders.html', {'orders': ord})
