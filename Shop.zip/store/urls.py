from django.contrib import admin
from django.urls import path
from .views import signup, logout, cart, checkout
from .views import orders
from .views import Index
from .views import Login
from .middlewares.auth import auth_middleware

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup', signup, name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart', cart, name='cart'),
    path('checkout', checkout, name='checkout'),
    path('orders', auth_middleware(orders.as_view()), name='order'),
]
